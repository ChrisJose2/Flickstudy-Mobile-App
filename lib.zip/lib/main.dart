import 'package:flutter/material.dart';
import 'package:flutter_architecture/common/styles/app_colors.dart';
import 'package:flutter_architecture/user.repository.dart';
import 'package:flutter_architecture/user.viewmodel.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'common/routing/app_routes.dart';
import 'home.screen.dart';
import 'language.dart';
import 'user.viewmodel.dart';

main() async {
  
  WidgetsFlutterBinding.ensureInitialized();
  SharedPreferences.setMockInitialValues({});
  //flutter gen-l10n
  final userViewModel = UserViewModel(
      userRepo: UserRepository(prefs: await SharedPreferences.getInstance()));
  final language = Language();

  await userViewModel.init();

  runApp(MultiProvider(
      providers: [
        ChangeNotifierProvider<UserViewModel>.value(value: userViewModel),
        ChangeNotifierProvider<Language>.value(value: language),

      ],
      child: Consumer<Language>(
      builder: (context, language, _)
      {
      return MaterialApp(
        onGenerateTitle: (context) => AppLocalizations.of(context).helloWorld,
        localizationsDelegates: AppLocalizations.localizationsDelegates,
        supportedLocales: AppLocalizations.supportedLocales,
        locale: language.currentLocale,
        theme: ThemeData(
          primaryColor: AppColors.primary,
        ),
        initialRoute: AppRoutes.home,
        routes: AppRoutes.routes,
      );})));
}
