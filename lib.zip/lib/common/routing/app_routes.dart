import 'package:flutter/material.dart';
import 'package:flutter_architecture/modules/authentication/forgot_password/forgot_password_view.dart';
import 'package:flutter_architecture/modules/authentication/login/via_username_password/view/login_with_password_view.dart';
import 'package:flutter_architecture/modules/authentication/login_with_otp/login_with_otp_view.dart';
import 'package:flutter_architecture/modules/authentication/register/register_view.dart';
import 'package:flutter_architecture/modules/notification/view/notification_list_view.dart';
import 'package:flutter_architecture/modules/pay_bill/search_device/view/search_device_view.dart';
import 'package:flutter_architecture/modules/profile/view/profile_view.dart';
import 'package:flutter_architecture/modules/rating/view/rating_view.dart';
import 'package:flutter_architecture/modules/recharge_isp_portal/view/recharge_isp_portal_view.dart';
import 'package:flutter_architecture/modules/tickets/list/view/ticket_list_view.dart';
import 'package:flutter_architecture/modules/wallet/wallet_add/view/wallet_add.dart';
import 'package:flutter_architecture/modules/wallet/wallet_list/view/wallet_list_view.dart';


import '../../home.screen.dart';
import '../../modules/faq/view/faq_view.dart';
import '../../modules/manage_team_members/view/manage_team_member_view.dart';
class AppRoutes {
  static const String home = '/';
  static const String login = '/login';
  static const String login_with_otp = '/login_with_otp';
  static const String register = '/register';
  static const String forgot_password = '/forgot_password';
  static const String profile = '/profile';
  static const String notification_list = '/notification_list';
  static const String wallet_list = '/wallet_list';
  static const String wallet_add = '/wallet_add';
  static const String faq = '/faq';
  static const String manage_team_member = '/manage_team_member';
  static const String pay_bill_search_device = '/pay_bill_search_device';
  static const String rating = '/rating';
  static const String ticket_list = '/ticket_list';
  static const String recharge_isp_portal = '/recharge_isp_portal';

  static Map<String, WidgetBuilder> routes = {
    home: (context) => HomeScreen(),
    login: (context) => LoginView(),
    login_with_otp: (context) => LoginWithOTPView(),
    register: (context) => RegisterView(),
    forgot_password: (context) => ForgotPasswordView(),
    profile: (context) => ProfileView(),
    notification_list: (context) => NotificationListView(),
    wallet_list: (context) => WalletListView(),
    wallet_add: (context) => WalletAddView(),
    faq: (context) => FaqView(),
    manage_team_member: (context) => ManageTeamMemberListView(),
    pay_bill_search_device: (context) => SearchDeviceView(),
    rating: (context) => RatingView(),
    ticket_list: (context) => TicketListView(),
    recharge_isp_portal: (context) => RechargeISPPortalView(),
  };
}