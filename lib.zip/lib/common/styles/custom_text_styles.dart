import 'package:flutter/material.dart';

import 'app_colors.dart';

class CustomTextStyles {
  static const TextStyle formField = TextStyle(
    fontFamily: 'Montserrat',
    fontSize: 14.0,
    letterSpacing: 1.1,
    color: Colors.black,
    fontWeight: FontWeight.normal
  );
  static const TextStyle formFieldMandatory = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 14.0,
      letterSpacing: 1.1,
      color: Colors.red,
      fontWeight: FontWeight.w500
  );
  static const TextStyle buttonText = TextStyle(
    fontFamily: 'Montserrat',
    fontSize: 15.0,
    color: Colors.white,
  );
  static const TextStyle titleMaxBold = TextStyle(
    fontFamily: 'Montserrat',
    fontSize: 20.0,
    color: AppColors.primary,
    fontWeight: FontWeight.w900
  );
  static const TextStyle titleMaxBoldBlack = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 20.0,
      color: AppColors.black,
      fontWeight: FontWeight.w900
  );
  static const TextStyle titleBoldWhite = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 20.0,
      color: AppColors.white,
      fontWeight: FontWeight.bold
  );
  static const TextStyle titleSuperMaxBoldPrimary = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 25.0,
      color: AppColors.primary,
      fontWeight: FontWeight.w900
  );

  static const TextStyle semiBold = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 13.0,
      color: AppColors.primary,
      fontWeight: FontWeight.w400
  );
  static const TextStyle visitingCardsubtitle = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 13.0,
      color: AppColors.primary,
      fontWeight: FontWeight.w900
  );
  static const TextStyle subtitleText = TextStyle(
    fontFamily: 'Montserrat',
    fontSize: 11.0,
    letterSpacing: 1.1,
    color: AppColors.subtitle,
  );
  static const TextStyle titleText = TextStyle(
    fontFamily: 'Montserrat',
    fontSize: 13.0,
    letterSpacing: 1.1,
    color: AppColors.primary,
    fontWeight: FontWeight.bold
  );
  static const TextStyle redText = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 13.0,
      letterSpacing: 1.1,
      color: Colors.red,
      fontWeight: FontWeight.bold

  );
  static const TextStyle listTitleText = TextStyle(
    fontFamily: 'Montserrat',
    fontSize: 12.0,
    letterSpacing: 1.1,
    color: AppColors.black,
  );
  static const TextStyle listTitleTextWhite = TextStyle(
    fontFamily: 'Montserrat',
    fontSize: 12.0,
    letterSpacing: 1.1,
    color: AppColors.white,
  );
  static const TextStyle listTitleTextBold = TextStyle(
    fontFamily: 'Montserrat',
    fontSize: 12.0,
    letterSpacing: 1.1,
    color: AppColors.black,
    fontWeight: FontWeight.bold
  );
  static const TextStyle routerStatusText = TextStyle(
    fontFamily: 'Montserrat',
    fontSize: 14.0,
    letterSpacing: 1.1,
    color: AppColors.primary,
  );
  static const TextStyle selectedBottomNav = TextStyle(
    fontFamily: 'Montserrat',
    fontSize: 9.0,
    letterSpacing: 1.1,
    color: AppColors.primary,
    fontWeight: FontWeight.w500
  );
  static const TextStyle bottomNavText = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 9.0,
      letterSpacing: 1.1,
      color: AppColors.black,
      fontWeight: FontWeight.w500
  );
  static const TextStyle titleBarText = TextStyle(
    fontFamily: 'Montserrat',
    fontSize: 16.0,
    color: AppColors.white
  );
  static const TextStyle titleBarTextPrimary = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 16.0,
      color: AppColors.primary
  );
  static const TextStyle text_18_black_bold = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 18.0,
      color: AppColors.black,
      fontWeight: FontWeight.bold
  );

  static const TextStyle titleSuperMaxBoldWhite = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 25.0,
      color: AppColors.white, fontWeight: FontWeight.w900
  );
  static const TextStyle titleSuperMaxBoldBlack = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 25.0,
      color: AppColors.black, fontWeight: FontWeight.w900
  );
  static const TextStyle titleSuperMaxUltraBlack = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 35.0,
      color: AppColors.black, fontWeight: FontWeight.w500
  );
  static const TextStyle walletBalanceSubtitle = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 14.0,
      color: AppColors.white, fontWeight: FontWeight.normal
  );
  static const TextStyle addWalletBalanceText = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 16.0,
      color: AppColors.white, fontWeight: FontWeight.normal
  );
  static const TextStyle creditAmountText = TextStyle(
    fontFamily: 'Montserrat',
    fontSize: 12.0,
    letterSpacing: 1.1,
    color: AppColors.green,
  );
  static const TextStyle badgeText = TextStyle(
    fontFamily: 'Montserrat',
    fontSize: 8.0,
    letterSpacing: 1.1,
    color: AppColors.primary,
    fontWeight: FontWeight.w900
  );
  static const TextStyle primary_14_Text = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 14.0,
      letterSpacing: 1.1,
      color: AppColors.primary
  );
  static const TextStyle primary_14_Text_bold = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 14.0,
      letterSpacing: 1.1,
      color: AppColors.primary,
      fontWeight: FontWeight.bold
  );
  static const TextStyle black_14_Text = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 14.0,
      letterSpacing: 1.1,
      color: AppColors.black
  );
  static const TextStyle black_14_Text_underline = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 14.0,
      letterSpacing: 1.1,
      color: AppColors.black,
      decoration: TextDecoration.underline,
  );
  static const TextStyle black_14_Text_bold = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 14.0,
      letterSpacing: 1.1,
      color: AppColors.black,
      fontWeight: FontWeight.bold
  );
  static const TextStyle white_14_Text = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 14.0,
      letterSpacing: 1.1,
      color: AppColors.white
  );
  static const TextStyle white_12_Text = TextStyle(
      fontFamily: 'Montserrat',
      fontSize: 12.0,
      letterSpacing: 1.1,
      color: AppColors.white
  );
}
