import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryDark = Color(0xff800D50);
  static const Color primary = Color(0xffd92b90);
  static const Color primaryLight = Color(0xffFBEAF4);
  static const Color secondary = Color(0xffFFC107);
  static const Color background = Color(0xffF2F2F2);
  static const Color white = Color(0xffFFFFFF);
  static const Color black = Color(0xff000000);
  static const Color green = Color(0xff00ff00);
  static const Color subtitle = Color(0xffADADAD);
  static const Color grey = Color(0xffF0F0F0);
  static const Color darkGrey = Color(0xff808080);
  static const Color red = Color(0xffff0000);
  static const Color yellow = Color(0xffFFAA00);
  static const Color purple = Color(0xff644080);
}