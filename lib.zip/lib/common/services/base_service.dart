import 'package:http/http.dart' as http;

import '../utilities/constants.dart';

class BaseService{

  Future<dynamic> post(String endpoint,dynamic body) async {
    dynamic response;
    try {
      response = await http.post(
        Uri.parse(AppConstants.BASE_URL+endpoint,body),
      );

    } catch (e) {
      //TODO
    }
    return response;

  }
  static Future<dynamic> get(String endpoint) async {
    dynamic response;
    try {
      response = await http.get(
        Uri.parse(AppConstants.BASE_URL+endpoint),
      );

    } catch (e) {
      //TODO
    }
    return response;

  }
  static Future<dynamic> put(String endpoint,dynamic body) async {
    dynamic response;
    try {
      response = await http.put(
        Uri.parse(AppConstants.BASE_URL+endpoint,body),
      );

    } catch (e) {
      //TODO
    }
    return response;

  }
  static Future<dynamic> delete(String endpoint,dynamic body) async {
    dynamic response;
    try {
      response = await http.delete(
        Uri.parse(AppConstants.BASE_URL+endpoint,body),
      );

    } catch (e) {
      //TODO
    }
    return response;

  }
}