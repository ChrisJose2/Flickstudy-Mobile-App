import 'package:connectivity_plus/connectivity_plus.dart';

class AppConstants{
  static const REPORT_TYPE="Report";
  static const FORM_TYPE="Form";
  static const HOME="HOME";
  static const WALLET="WALLET";
  static const TICKETS="TICKETS";
  static const RECHARGE_ISP="RECHARGE_ISP";
  static const BASE_URL="";


  static Future<bool> checkInternetConnectivity() async{
    final connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.mobile || connectivityResult == ConnectivityResult.wifi || connectivityResult == ConnectivityResult.vpn) {
      return true;
    } else{
      return false;
    }
  }
}
enum Environments {
  dev,
  staging,
  production,
}