import 'package:flutter/material.dart';
import 'package:flutter_architecture/common/styles/app_colors.dart';
import 'package:flutter_architecture/common/styles/custom_text_styles.dart';
import 'package:flutter_architecture/common/utilities/constants.dart';

import 'text_widget.dart';

class BottomNavigationBarView extends StatelessWidget {
  final String selected; // Declare the parameter as an instance variable
  final VoidCallback onHomePressed;
  final VoidCallback onTicketPressed;
  final VoidCallback onWalletPressed;
  final VoidCallback onRechargePressed;

  const BottomNavigationBarView({super.key, required this.selected,required this.onHomePressed,required this.onTicketPressed,required this.onWalletPressed,required this.onRechargePressed,}); //
  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      child: Container(
        height: 60.0,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            GestureDetector(
              onTap: onHomePressed,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    Stack(
                      children: [
                        Icon(Icons.home,color: isSelected(AppConstants.HOME)?AppColors.primary:AppColors.black,),
                        Positioned(
                            top: 0,
                            right: 0,
                            child: Container(
                                padding: EdgeInsets.all(2),
                                decoration: BoxDecoration(
                                  color: AppColors.primaryLight,
                                  shape: BoxShape.circle,
                                ),
                                child: CustomTextField(text: "10",styleFace: CustomTextStyles.badgeText,
                                )))
                      ],
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    CustomTextField(text: 'Home',styleFace:isSelected(AppConstants.HOME)?CustomTextStyles.selectedBottomNav:CustomTextStyles.bottomNavText)
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: onTicketPressed,
              child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      Icon(Icons.file_copy,color: isSelected(AppConstants.TICKETS)?AppColors.primary:AppColors.black,),
                      const SizedBox(
                        height: 5,
                      ),
                      CustomTextField(text: 'Tickets',styleFace:isSelected(AppConstants.TICKETS)?CustomTextStyles.selectedBottomNav:CustomTextStyles.bottomNavText)
                    ],
                  )),
            ),
            GestureDetector(
              onTap: onWalletPressed,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    Icon(Icons.credit_card,color: isSelected(AppConstants.WALLET)?AppColors.primary:AppColors.black,),
                    const SizedBox(
                      height: 5,
                    ),
                    CustomTextField(text: 'Wallet',styleFace:isSelected(AppConstants.WALLET)?CustomTextStyles.selectedBottomNav:CustomTextStyles.bottomNavText)
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: onRechargePressed,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    Icon(Icons.person,color: isSelected(AppConstants.RECHARGE_ISP)?AppColors.primary:AppColors.black,),
                    const SizedBox(
                      height: 5,
                    ),
                    CustomTextField(text: 'Recharge ISP',styleFace:isSelected(AppConstants.RECHARGE_ISP)?CustomTextStyles.selectedBottomNav:CustomTextStyles.bottomNavText)
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  bool isSelected(String type){
    bool result =false;
    if(selected==type)
      return true;
    return result;
  }
}
