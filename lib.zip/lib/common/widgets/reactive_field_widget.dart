// ignore_for_file: constant_identifier_names, must_be_immutable
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import 'package:flutter/services.dart';

import 'package:flutter/material.dart';
import 'package:reactive_forms/reactive_forms.dart';

enum ReactiveFields {
  TEXT,
}

class ReactiveField extends StatelessWidget {
  final ReactiveFields type;
  final String controllerName;
  final int maxLines;
  final double width;
  final double? height;
  final Map<String, String>? validationMesseges;
  final TextInputType? keyboardType;
  final String? hint, radioTitle, radioVal;

  final bool secure, autoFocus, readOnly, filled, showBorders;
  final List<DropdownMenuItem<dynamic>>? items;
  final IconButton? iconButton;
  final Widget? prefixButton;
  final Widget? suffixButton;
  final BuildContext? context;
  final TextDirection? textDirection;
  final Function? onchange;
  final VoidCallback? onEditing;
  final VoidCallback? onTapFunction;
  final String? label;
  final TextInputAction? textInputAction;
  final bool accent;
  DateTime? lastDate;
  List<TextInputFormatter>? inputFormat;
  int? maxLength;

  final List<Widget> Function(BuildContext)? selectedItemBuilder;

  ReactiveField(
      {Key? key,
        this.type = ReactiveFields.TEXT,
        required this.controllerName,
        this.showBorders = true,
        this.validationMesseges,
        this.hint,
        this.width = double.infinity,
        this.height,
        this.keyboardType = TextInputType.visiblePassword,
        this.secure = false,
        this.autoFocus = false,
        this.readOnly = false,
        this.label,
        this.onchange,
        this.iconButton,
        this.onEditing,
        this.prefixButton,
        this.suffixButton,
        this.selectedItemBuilder,
        this.radioTitle = '',
        this.maxLines = 1,
        this.textDirection,
        this.filled = false,
        this.radioVal = '',
        this.items,
        this.context,
        this.textInputAction,
        this.lastDate,
        this.accent = false,
        this.inputFormat,
        this.onTapFunction,
        this.maxLength})
      : super(key: key) {
    lastDate = DateTime.now();
  }

  @override
  Widget build(BuildContext context) {
    final locale = AppLocalizations.of(context);
    return Container(
        margin: const EdgeInsets.only(top: 12, bottom: 8),
        child: buildReactiveField(locale, context));
  }

  buildReactiveField(locale, context) {
    Map<String, String Function(Object)> validationM = {
      ValidationMessage.required: (error) => 'Required',
      // ValidationMessage.minLength: (error) =>
      //     'The password must be at least ${(error as Map)['requiredLength']} characters long',

      ValidationMessage.minLength: (error) =>
      validationMesseges?[ValidationMessage.minLength] ?? "minLength",
      ValidationMessage.maxLength: (error) =>
      validationMesseges?[ValidationMessage.maxLength] ?? "maxLength",
      ValidationMessage.mustMatch: (error) =>
      locale.get("Passwords don't match") ?? "Passwords don't match",
      ValidationMessage.email: (error) =>
      locale.get("Please enter valid email") ?? "Please enter valid email",
      ValidationMessage.pattern: (error) =>
      locale.get("Field doesn't match the pattern") ??
          "Field doesn't match the pattern",
    };

    return ReactiveTextField(
      onChanged: (control) => onchange,
      onTap: (control) =>onTapFunction,
      maxLength: maxLength,
      inputFormatters: inputFormat,
      formControlName: controllerName,
      validationMessages: validationM,
      keyboardType: keyboardType,
      textDirection: textDirection,
      maxLines: maxLines,
      decoration: const InputDecoration().copyWith(
          hintText: hint,
          prefixIcon: prefixButton != null
              ? Padding(
            padding: const EdgeInsets.all(10.0),
            child: prefixButton,
          )
              : null,
          suffixIcon: suffixButton != null
              ? Padding(
            padding: const EdgeInsets.all(10.0),
            child: suffixButton,
          )
              : null,
          alignLabelWithHint: true),
      autofocus: autoFocus,
      readOnly: readOnly,
      textInputAction: textInputAction,
      obscureText: secure,
    );
  }
}