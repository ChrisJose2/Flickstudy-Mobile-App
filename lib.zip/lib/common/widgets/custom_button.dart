import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:flutter_architecture/common/widgets/text_widget.dart';

import '../styles/app_colors.dart';
import '../styles/custom_text_styles.dart';

class CustomButton extends StatelessWidget {
  final String text;
  final Color color;
  final VoidCallback onPressed;

  CustomButton({
    required this.text,
    this.color=AppColors.white,
    required this.onPressed
  });

  @override
  Widget build(BuildContext context) {
    return Container(
        width: MediaQuery.of(context).size.width*0.9,
        height: 50,
        decoration: BoxDecoration(
        color: AppColors.primary,
        borderRadius: BorderRadius.circular(40),
    ),
    child:ElevatedButton(
      onPressed:onPressed,
      style: ElevatedButton.styleFrom(
        primary: AppColors.primary,
        onPrimary: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
      ),
      child: CustomTextField(text:text,upperCase: false,color: AppColors.white,styleFace: CustomTextStyles.buttonText,),
    ));
  }
}
