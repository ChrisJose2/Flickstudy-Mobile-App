import 'package:flutter/material.dart';
import 'package:flutter_architecture/common/routing/app_routes.dart';
import 'package:flutter_architecture/common/styles/app_colors.dart';
import 'package:flutter_architecture/common/styles/custom_text_styles.dart';
import 'package:flutter_architecture/common/utilities/constants.dart';

import 'text_widget.dart';

class AppBarView extends StatelessWidget implements PreferredSizeWidget{
  final String title;
  final bool showRightBar;
  final double elevation;

  AppBarView({super.key,required this.title,this.showRightBar=false,this.elevation=0});
  @override
  Widget build(BuildContext context) {
    return AppBar(
        elevation: elevation,
        backgroundColor: AppColors.black,
        iconTheme: IconThemeData(
          color: AppColors.white, //change your color here
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: CustomTextField(
                styleFace: CustomTextStyles.titleBarText,
                upperCase: false,
                text: title,

              ),
            ),
            /*GestureDetector(
              onTap: () {
                    Navigator.pushNamed(context, AppRoutes.notification_list);
              },
              child: Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 15, 0),
                  child: Icon(
                    Icons.notifications,
                  )),
            ),
            SizedBox(width: 10,),
            GestureDetector(
              onTap: () {
              },
              child: Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                  child: Row(
                    children: [
                      Icon(
                        Icons.star,
                      ),
                      SizedBox(width: 10,),
                      CustomTextField(
                        styleFace: CustomTextStyles.titleBarText,
                        text: "4.5 ",

                      ),

                    ],
                  )),
            ),*/
          ],
        ),
        centerTitle: false);
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

}
