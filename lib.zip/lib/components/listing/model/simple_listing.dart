class SimpleListingModel{
  final String title;

  SimpleListingModel({required this.title});

  factory SimpleListingModel.fromJson(Map<String, dynamic> json) {
  return SimpleListingModel(
  title: json['title'] as String,
  );
  }



}