
import '../../../common/responses/base_response.dart';
import '../model/simple_listing.dart';

class SimpleListingResponse extends BaseResponse{
    List<SimpleListingModel> simpleListingModelList=[];

    SimpleListingResponse.fromJson(var json) : super.fromJson(json){
      // simpleListingModelList=json.ea
    }

}