import 'package:http/http.dart';

import '../../../common/services/base_service.dart';
import '../response/simple_listing_response.dart';

abstract class ListingService extends BaseService{

  fetchData(String componentType) async { }

}