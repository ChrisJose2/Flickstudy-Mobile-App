import 'package:http/http.dart';

import '../../../common/services/base_service.dart';
import '../response/simple_listing_response.dart';
import 'listing_service.dart';

class ListingServiceImpl extends ListingService{

   @override
  Future<SimpleListingResponse> fetchData(String componentType) async {

    dynamic response;
    try {
      response = await BaseService.get("url");

    } catch (e) {
      //TODO
    }
    return SimpleListingResponse.fromJson(response);

  }

}