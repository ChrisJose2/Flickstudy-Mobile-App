import 'package:avatar_glow/avatar_glow.dart';
import 'package:flutter/material.dart';
import 'package:flutter_architecture/common/routing/app_routes.dart';
import 'package:flutter_architecture/common/styles/app_colors.dart';
import 'package:flutter_architecture/common/styles/custom_text_styles.dart';
import 'package:flutter_architecture/common/utilities/constants.dart';
import 'package:flutter_architecture/common/widgets/app_bar.dart';
import 'package:flutter_architecture/common/widgets/bottom_navigation.dart';
import 'package:flutter_architecture/common/widgets/text_widget.dart';
import 'dart:math' as math; // import this

class RechargeISPPortalView extends StatefulWidget {
  @override
  RechargeISPPortalState createState() => RechargeISPPortalState();
}

class RechargeISPPortalState extends State<RechargeISPPortalView> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        floatingActionButton: FloatingActionButton(
          backgroundColor: AppColors.primary,
          onPressed: (){
            _showRechargeBottomSheet(context);
          },
          child: Icon(Icons.check_circle),
        ),
        bottomNavigationBar: BottomNavigationBarView(
            selected: AppConstants.RECHARGE_ISP,
            onHomePressed: () => navigateTab(AppConstants.HOME),
            onWalletPressed: () => navigateTab(AppConstants.WALLET),
            onTicketPressed: () => navigateTab(AppConstants.TICKETS),
            onRechargePressed: () => navigateTab(AppConstants.RECHARGE_ISP)),
        body: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  height: 50,
                  padding: EdgeInsets.fromLTRB(30, 10, 0, 10),
                  color: AppColors.darkGrey,
                  child: Row(
                    children: [
                      CustomTextField(text: "TWELVE ",styleFace: CustomTextStyles.titleSuperMaxBoldWhite,),
                      Container(
                          margin:EdgeInsets.only(top:5),
                          child: CustomTextField(text: "Months Plan",upperCase: false,styleFace: CustomTextStyles.titleBoldWhite,)),
                    ],
                  ),
                ),
                ListView.builder(
                  physics:NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: 4,
                  itemBuilder: (context, index) {
                    return getCustomerCard(index);
                  },
                ),
                Container(
                  height: 50,
                  padding: EdgeInsets.fromLTRB(30, 10, 0, 10),
                  color: AppColors.primaryDark,
                  child: Row(
                    children: [
                      CustomTextField(text: "FOUR ",styleFace: CustomTextStyles.titleSuperMaxBoldWhite,),
                      Container(
                          margin:EdgeInsets.only(top:5),
                          child: CustomTextField(text: "Months Plan",upperCase: false,styleFace: CustomTextStyles.titleBoldWhite,)),
                    ],
                  ),
                ),
                ListView.builder(
                  physics:const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: 2,
                  itemBuilder: (context, index) {
                    return getCustomerCard(index);
                  },
                ),
                Container(
                  height: 50,
                  padding: EdgeInsets.fromLTRB(30, 10, 0, 10),
                  color: AppColors.purple,
                  child: Row(
                    children: [
                      CustomTextField(text: "THREE ",styleFace: CustomTextStyles.titleSuperMaxBoldWhite,),
                      Container(
                          margin:EdgeInsets.only(top:5),
                          child: CustomTextField(text: "Months Plan",upperCase: false,styleFace: CustomTextStyles.titleBoldWhite,)),
                    ],
                  ),
                ),
                ListView.builder(
                  physics:NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: 2,
                  itemBuilder: (context, index) {
                    return getCustomerCard(index);
                  },
                ),
                Container(
                  height: 50,
                  padding: EdgeInsets.fromLTRB(30, 10, 0, 10),
                  color: AppColors.purple,
                  child: Row(
                    children: [
                      CustomTextField(text: "TWO ",styleFace: CustomTextStyles.titleSuperMaxBoldWhite,),
                      Container(
                          margin:EdgeInsets.only(top:5),
                          child: CustomTextField(text: "Months Plan",upperCase: false,styleFace: CustomTextStyles.titleBoldWhite,)),
                    ],
                  ),
                ),
                ListView.builder(
                  physics:NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: 2,
                  itemBuilder: (context, index) {
                    return getCustomerCard(index);
                  },
                ),
                Container(
                  height: 50,
                  padding: EdgeInsets.fromLTRB(30, 10, 0, 10),
                  color: AppColors.purple,
                  child: Row(
                    children: [
                      CustomTextField(text: "ONE ",styleFace: CustomTextStyles.titleSuperMaxBoldWhite,),
                      Container(
                          margin:EdgeInsets.only(top:5),
                          child: CustomTextField(text: "Month Plan",upperCase: false,styleFace: CustomTextStyles.titleBoldWhite,)),
                    ],
                  ),
                ),
                ListView.builder(
                  physics:NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: 2,
                  itemBuilder: (context, index) {
                    return getCustomerCard(index);
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
  getCustomerCard(int index){
    return Row(
      children: [
        Expanded(
          child: Container(

            margin: EdgeInsets.fromLTRB(10,10,10,10),
            decoration: BoxDecoration(
              color: AppColors.primaryLight,
              borderRadius: BorderRadius.circular(15.0),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  spreadRadius: 2,
                  blurRadius: 5,
                  offset: Offset(0, 3),
                ),
              ],
            ),
            child: Column(
              children: <Widget>[
                Container(
                  width: MediaQuery.of(context).size.width,
                  padding: EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    color: AppColors.primaryLight,
                    borderRadius: BorderRadius.only(topLeft: Radius.circular(15),topRight: Radius.circular(15)),

                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const AvatarGlow(
                              endRadius: 15,
                              animate: true,
                              child: Material(
                                elevation: 8.0,
                                shape: CircleBorder(),
                                child: CircleAvatar(
                                  backgroundColor: AppColors.yellow,
                                  radius: 5,
                                ),
                              )),
                          SizedBox(width: 5,),
                          Expanded(
                            child: CustomTextField(
                              text: "Rakesh Biswas",
                              styleFace: CustomTextStyles.listTitleText,
                              upperCase: false,
                            ),
                          ),

                        ],
                      ),
                      Row(
                        children: [
                          Align(
                            alignment: Alignment.topLeft,
                            child: Container(
                              margin: EdgeInsets.only(left: 35),
                              height: 20,
                              width: 50,
                              decoration: BoxDecoration(
                                  color: AppColors.primary,
                                  borderRadius: BorderRadius.circular(5)
                              ),
                              child: Center(child: CustomTextField(text: "Install",upperCase: false,styleFace: CustomTextStyles.listTitleTextWhite,)),
                            ),
                          ),
                          SizedBox(width: 10,),
                          Image.asset("assets/imgs/superfast.png",height: 15,),
                          SizedBox(width: 10,),
                          Image.asset("assets/imgs/call.png",height: 15,),
                          SizedBox(width: 10,),
                          CustomTextField(text: "9872855412",styleFace: CustomTextStyles.listTitleText),
                          SizedBox(width: 10,),
                          Image.asset("assets/imgs/router_24px.png",height: 15,),
                          SizedBox(width: 10,),
                          CustomTextField(text: "412365",styleFace: CustomTextStyles.listTitleText)
                        ],
                      )
                    ],
                  ),
                ),


              ],
            ),
          ),
        ),
        Checkbox(value: false, onChanged: null)

      ],
    );
  }

  navigateTab(String type) {
    if(type==AppConstants.HOME){
      Navigator.pushNamedAndRemoveUntil(context, AppRoutes.home,(Route<dynamic> route) => false);
    }
    if(type==AppConstants.WALLET){
      Navigator.pushNamedAndRemoveUntil(context, AppRoutes.wallet_list,(Route<dynamic> route) => false);
    }

    if(type==AppConstants.TICKETS){
      Navigator.pushNamedAndRemoveUntil(context, AppRoutes.ticket_list,(Route<dynamic> route) => false);
    }
  }
  void _showRechargeBottomSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.0)),
      ),
      builder: (BuildContext context) {
        return Container(
          padding: EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Center(child: Image.asset("assets/imgs/recharge_sign.png")),
              SizedBox(height: 10),
              Center(
                child: CustomTextField(
                  text:'Recharge customer account on the ISP Portal for',upperCase: false,
                  styleFace: CustomTextStyles.black_14_Text,
                ),
              ),
              SizedBox(height: 10),
              Center(
                child: CustomTextField(
                  text:'01 Month',upperCase: false,
                  styleFace: CustomTextStyles.titleMaxBoldBlack,
                ),
              ),
              Center(
                child: ElevatedButton(

                  onPressed: () {
                    // Action for the "Yes" button
                    Navigator.pop(context);

                  },
                  style: ElevatedButton.styleFrom(

                    primary: AppColors.primary,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    margin: EdgeInsets.all(10),

                    child: Center(
                      child: CustomTextField(
                        text: "Alright",upperCase: false, styleFace: CustomTextStyles.white_14_Text,),
                    ),
                  ),
                ),
              )
            ],
          ),
        );
      },
    );
  }

}
