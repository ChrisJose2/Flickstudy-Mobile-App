import 'package:flutter/material.dart';
import 'package:flutter_architecture/common/widgets/custom_button.dart';
import 'package:flutter_architecture/common/widgets/text_widget.dart';
import 'package:reactive_forms/reactive_forms.dart';
import '../../../common/styles/app_colors.dart';
import '../../../common/widgets/app_bar.dart';
import '../../../common/widgets/reactive_field_widget.dart';


class ManageTeamMemberListView extends StatelessWidget {
  ManageTeamMemberListView({Key? key}) : super(key: key);
  final form = FormGroup({
    'name': FormControl<String>(validators: [Validators.required]),
    'mobile': FormControl<String>(
        validators: [Validators.minLength(10),Validators.maxLength(10), Validators.required]),
    'email': FormControl<String>(validators: [
      Validators.minLength(3),
      Validators.required,
      Validators.email,
      Validators.maxLength(3)
    ]),


  });
  List<String> cards=["Manish"];
  @override
  Widget build(BuildContext context) {

    return
      SafeArea(
        child: Scaffold(
          appBar: AppBarView(title:"Manage Team"),
          body: Container(
            color: Colors.white,
            padding: EdgeInsets.all(15),
            child: Column(
              children: [
                Expanded(
                  child: Container(
                    child: cards!=null && cards.length>0?
                    Column(children: [
                        for(String cardItem in cards)
                          getCard(cardItem,context)

                      ],)


                    :Expanded(
                      child : Container(
                        margin: EdgeInsets.only(top:MediaQuery.of(context).size.height*0.3),
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Image.asset("assets/images/no_card.png"),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: CustomTextField(text: "No team members added"),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child:  CustomTextField(text: "Added members will appear here"),
                            ),
                            getAddButton(context)
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: getAddButton(context),
                )
              ],
            ),
          ),

        ),

      );
  }
  getAddButton(context){

    return CustomButton(text: "Add New", onPressed:(){
      _openAddMemberBottomSheet(context);
    });
  }
  getSaveButton(context){
    return CustomButton(text: "Save", onPressed: (){
      Navigator.pop(context);
    });
  }
  Widget getCard(cardItem,context){
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [

                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(4.0),
                            child: CustomTextField(text: cardItem,)
                          ),
                          Padding(
                            padding: const EdgeInsets.all(4.0),
                            child: CustomTextField(text: cardItem,),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 20,),
                    GestureDetector(
                        onTap: (){

                        },
                        child: Icon(Icons.delete_outline_rounded,color: AppColors.red,)),
                    SizedBox(width: 20,),
                    GestureDetector(
                        onTap: (){

                        },
                        child: Icon(Icons.edit,color: AppColors.black,))
                  ],
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
  void _openAddMemberBottomSheet(context) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        builder: (BuildContext bc) {
          return SingleChildScrollView(
            child: Container(
              padding: const EdgeInsets.fromLTRB(20, 30, 20, 30),
              decoration: BoxDecoration(
                  color: Colors.white,
                  //could change this to Color(0xFF737373),
                  shape: BoxShape.rectangle,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(15.0),
                      topRight: Radius.circular(15.0))),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(10, 0, 0, 10),
                    child: Container(
                        child: Opacity(
                          opacity: 0.7,
                          child: CustomTextField(text: "Add New Member",),
                        )),
                  ),
                  ReactiveForm(
                      formGroup: form,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ReactiveField(

                            controllerName: "name",
                            hint: "name",
                          ),
                          SizedBox(height: 10,),
                          ReactiveField(
                            controllerName: "email",
                            hint: "email",
                          ),
                          SizedBox(height: 10,),
                          ReactiveField(
                            controllerName: "mobile",
                            hint: "mobile",
                          ),
                          getSaveButton(context)
                        ],
                      )),

                ],
              ),
            ),
          );
        });
  }
}
