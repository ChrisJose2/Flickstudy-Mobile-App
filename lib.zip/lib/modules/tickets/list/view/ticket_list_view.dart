import 'package:avatar_glow/avatar_glow.dart';
import 'package:flutter/material.dart';
import 'package:flutter_architecture/common/routing/app_routes.dart';
import 'package:flutter_architecture/common/styles/app_colors.dart';
import 'package:flutter_architecture/common/styles/custom_text_styles.dart';
import 'package:flutter_architecture/common/utilities/constants.dart';
import 'package:flutter_architecture/common/widgets/app_bar.dart';
import 'package:flutter_architecture/common/widgets/bottom_navigation.dart';
import 'package:flutter_architecture/common/widgets/text_widget.dart';
import 'dart:math' as math; // import this

class TicketListView extends StatefulWidget {
  @override
  TicketListState createState() => TicketListState();
}

class TicketListState extends State<TicketListView> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        bottomNavigationBar: BottomNavigationBarView(
            selected: AppConstants.TICKETS,
            onHomePressed: () => navigateTab(AppConstants.HOME),
            onWalletPressed: () => navigateTab(AppConstants.WALLET),
            onTicketPressed: () => navigateTab(AppConstants.TICKETS),
            onRechargePressed: () => navigateTab(AppConstants.RECHARGE_ISP)),
        body: SafeArea(
          child: Column(
            children: [
              Container(
                height: 40,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Container(
                      width: 100,
                      height: 30,
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        color: AppColors.white,
                        borderRadius: BorderRadius.circular(10.0),
                        border: Border.all(
                          color: AppColors.primary,
                          width: 0.5,
                        ),
                      ),
                      child: Center(
                          child: CustomTextField(
                            text: "ToDo (8)",
                            upperCase: false,
                            styleFace: CustomTextStyles.primary_14_Text,
                          )),
                    ),
                    Container(
                      width: 130,
                      height: 30,
                      margin: EdgeInsets.all(5),
                      padding: EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        color: AppColors.primary,
                        borderRadius: BorderRadius.circular(10.0),
                        border: Border.all(
                          color: AppColors.white,
                          width: 0.5,
                        ),
                      ),
                      child: Center(
                          child: CustomTextField(
                            text: "In Progress (4)",
                            upperCase: false,
                            styleFace: CustomTextStyles.white_14_Text,
                          )),
                    ),
                  ],
                ),
              ),
              Divider(),
              Container(
                height: 40,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    Container(
                      width: 100,
                      height: 20,
                      padding: EdgeInsets.all(2),
                      margin: EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        color: AppColors.white,
                        borderRadius: BorderRadius.circular(10.0),
                        border: Border.all(
                          color: AppColors.primary,
                          width: 0.5,
                        ),
                      ),
                      child: Center(
                          child: CustomTextField(
                            text: "All (8)",
                            upperCase: false,
                            styleFace: CustomTextStyles.listTitleText,
                          )),
                    ),
                    Container(
                      width: 100,
                      height: 20,
                      margin: EdgeInsets.all(5),
                      padding: EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        color: AppColors.white,
                        borderRadius: BorderRadius.circular(10.0),
                        border: Border.all(
                          color: AppColors.primary,
                          width: 0.5,
                        ),
                      ),
                      child: Center(
                          child: CustomTextField(
                            text: "Me (4)",
                            upperCase: false,
                            styleFace: CustomTextStyles.listTitleText,
                          )),
                    ),
                    Container(
                      width: 100,
                      height: 20,
                      margin: EdgeInsets.all(5),
                      padding: EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        color: AppColors.white,
                        borderRadius: BorderRadius.circular(10.0),
                        border: Border.all(
                          color: AppColors.primary,
                          width: 0.5,
                        ),
                      ),
                      child: Center(
                          child: CustomTextField(
                            text: "Sateesh (2)",
                            upperCase: false,
                            styleFace: CustomTextStyles.listTitleText,
                          )),
                    ),
                    Container(
                      width: 100,
                      height: 20,
                      margin: EdgeInsets.all(5),
                      padding: EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        color: AppColors.white,
                        borderRadius: BorderRadius.circular(10.0),
                        border: Border.all(
                          color: AppColors.primary,
                          width: 0.5,
                        ),
                      ),
                      child: Center(
                          child: CustomTextField(
                            text: "Rohit (2)",
                            upperCase: false,
                            styleFace: CustomTextStyles.listTitleText,
                          )),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 10,),
              Expanded(
                child: ListView.builder(
                  itemCount: 10,
                  itemBuilder: (context, index) {
                    return getTicketCard(index);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  getTicketCard(int index){
    return Column(
      children: [
        Container(
          width: MediaQuery.of(context).size.width,
          margin: EdgeInsets.fromLTRB(0,10,0,10),
          decoration: BoxDecoration(
            color: AppColors.white,
            borderRadius: BorderRadius.circular(15.0),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                spreadRadius: 2,
                blurRadius: 5,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            children: <Widget>[
              Container(
                width: MediaQuery.of(context).size.width,
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.primaryLight,
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(15),topRight: Radius.circular(15)),

                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const AvatarGlow(
                            endRadius: 15,
                            animate: true,
                            child: Material(
                              elevation: 8.0,
                              shape: CircleBorder(),
                              child: CircleAvatar(
                                backgroundColor: AppColors.yellow,
                                radius: 5,
                              ),
                            )),
                        SizedBox(width: 20,),
                        Expanded(
                          child: CustomTextField(
                            text: "Rajat Solanki",
                            styleFace: CustomTextStyles.listTitleText,
                            upperCase: false,
                          ),
                        ),
                        Icon(Icons.call,color: AppColors.primary,)
                      ],
                    ),
                    Row(
                      children: [
                        Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            margin: EdgeInsets.only(left: 50),
                            height: 20,
                            width: 50,
                            decoration: BoxDecoration(
                                color: AppColors.primary,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: CustomTextField(text: "New",upperCase: false,styleFace: CustomTextStyles.white_14_Text,)),
                          ),
                        ),
                        SizedBox(width: 10,),
                        Image.asset("assets/imgs/router_24px.png",height: 20,),
                        SizedBox(width: 10,),
                        CustomTextField(text: "ID: ABC123")
                      ],
                    )
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 15.0,right: 15.0,top: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Image.asset("assets/imgs/internet_not_working.png",height: 15,width: 15,),
                    SizedBox(width: 20,),
                    Container(
                      child: CustomTextField(
                        text: "Internet is not working",
                        styleFace: CustomTextStyles.listTitleText,
                        upperCase: false,
                      ),
                    )
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 15.0,right: 15.0,top: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.access_time,color: AppColors.primary,),
                        SizedBox(width: 10,),
                        CustomTextField(text: "Later",upperCase: false,styleFace: CustomTextStyles.primary_14_Text,)
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        height: 40,
                        width: 40,
                        decoration: BoxDecoration(
                            color: AppColors.primary,
                            borderRadius: BorderRadius.circular(50)
                        ),
                        child: Transform(

                            alignment: Alignment.center,
                            transform: Matrix4.rotationY(math.pi),
                            child: Icon(Icons.reply,color: AppColors.white,)),
                      ),
                    ),
                  ],
                ),
              )

            ],
          ),
        ),

      ],
    );
  }

  navigateTab(String type) {
    if(type==AppConstants.HOME){
      Navigator.pushNamedAndRemoveUntil(context, AppRoutes.home,(Route<dynamic> route) => false);
    }
    if(type==AppConstants.WALLET){
      Navigator.pushNamedAndRemoveUntil(context, AppRoutes.wallet_list,(Route<dynamic> route) => false);
    }

    if(type==AppConstants.RECHARGE_ISP){
      Navigator.pushNamedAndRemoveUntil(
          context, AppRoutes.recharge_isp_portal, (Route<dynamic> route) => false);
    }
  }
}
