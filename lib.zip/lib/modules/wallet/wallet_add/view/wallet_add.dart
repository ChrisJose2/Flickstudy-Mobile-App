import 'package:flutter/material.dart';
import 'package:flutter_architecture/common/routing/app_routes.dart';
import 'package:flutter_architecture/common/styles/app_colors.dart';
import 'package:flutter_architecture/common/styles/custom_text_styles.dart';
import 'package:flutter_architecture/common/utilities/constants.dart';
import 'package:flutter_architecture/common/widgets/app_bar.dart';
import 'package:flutter_architecture/common/widgets/bottom_navigation.dart';
import 'package:flutter_architecture/common/widgets/custom_button.dart';
import 'package:flutter_architecture/common/widgets/custom_text_form_field.dart';
import 'package:flutter_architecture/common/widgets/text_widget.dart';


class WalletAddView extends StatefulWidget {
  @override
  WalletAddState createState() => WalletAddState();
}

class WalletAddState extends State<WalletAddView> {
  TextEditingController amountController=new TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarView(title: "Add Money to Wallet"),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.max,
            children: [
              Expanded(
                child: Column(
                  children: [
                    CustomTextFormField(labelText: "Enter Amount", controller: amountController),
                    SizedBox(
                      height: 5,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        GestureDetector(
                          onTap: (){
                            setAmount("100");
                          },
                          child: Container(
                            width: 60,
                            height: 30,
                            padding: EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              color: AppColors.grey,
                              borderRadius: BorderRadius.circular(10.0),

                            ),
                            child: Center(
                                child: CustomTextField(
                                  text: "+₹100",
                                  upperCase: false,
                                  styleFace: CustomTextStyles.listTitleText,
                                )),
                          ),
                        ),
                        GestureDetector(
                          onTap: (){
                            setAmount("200");
                          },
                          child: Container(
                            width: 60,
                            height: 30,
                            padding: EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              color: AppColors.grey,
                              borderRadius: BorderRadius.circular(20.0),

                            ),
                            child: Center(
                                child: CustomTextField(
                                  text: "+₹200",
                                  upperCase: false,
                                  styleFace: CustomTextStyles.listTitleText,
                                )),
                          ),
                        ),
                        GestureDetector(
                          onTap: (){
                            setAmount("1000");
                          },
                          child: Container(
                            width: 60,
                            height: 30,
                            padding: EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              color: AppColors.grey,
                              borderRadius: BorderRadius.circular(20.0),

                            ),
                            child: Center(
                                child: CustomTextField(
                                  text: "+₹1000",
                                  upperCase: false,
                                  styleFace: CustomTextStyles.listTitleText,
                                )),
                          ),
                        ),
                        GestureDetector(
                          onTap: (){
                            setAmount("2000");
                          },
                          child: Container(
                            width: 60,
                            height: 30,
                            padding: EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              color: AppColors.grey,
                              borderRadius: BorderRadius.circular(10.0),

                            ),
                            child: Center(
                                child: CustomTextField(
                                  text: "+₹2000",
                                  upperCase: false,
                                  styleFace: CustomTextStyles.listTitleText,
                                )),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(height: 10,),
              Align(
                alignment: Alignment.bottomCenter,
                child: CustomButton(text: 'Next', onPressed: (){
                  Navigator.pop(context);
                  //controller.loginUsers();
                }),

              ),
              SizedBox(height: 10,),
            ],
          ),
        ),
      ),
    );
  }

  navigateTab(String type) {
    /*if(type==AppConstants.HOME){
      selectedType=AppConstants.HOME;
    }
    if(type==AppConstants.TICKETS){
      selectedType=AppConstants.TICKETS;
    }*/
    if (type == AppConstants.WALLET) {
      Navigator.pushNamed(context, AppRoutes.wallet_list);
    }
    /*if(type==AppConstants.RECHARGE_ISP){
      selectedType=AppConstants.RECHARGE_ISP;
    }*/
  }
  setAmount(String value){
    amountController.text.isEmpty?amountController.text=value:amountController.text=(int.parse(amountController.text)+int.parse(value)).toString();
  }
}
