import 'package:flutter/material.dart';
import 'package:flutter_architecture/common/routing/app_routes.dart';
import 'package:flutter_architecture/common/styles/app_colors.dart';
import 'package:flutter_architecture/common/styles/custom_text_styles.dart';
import 'package:flutter_architecture/common/utilities/constants.dart';
import 'package:flutter_architecture/common/widgets/app_bar.dart';
import 'package:flutter_architecture/common/widgets/bottom_navigation.dart';
import 'package:flutter_architecture/common/widgets/text_widget.dart';


class WalletListView extends StatefulWidget {
  @override
  WalletListState createState() => WalletListState();
}

class WalletListState extends State<WalletListView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBarView(
          selected: AppConstants.WALLET,
          onHomePressed: () => navigateTab(AppConstants.HOME),
          onTicketPressed: () => navigateTab(AppConstants.TICKETS),
          onWalletPressed: () => navigateTab(AppConstants.WALLET),
          onRechargePressed: () => navigateTab(AppConstants.RECHARGE_ISP)),
      body: SafeArea(
        child: Column(
          children: [
            Container(
              color: AppColors.primary,
              width: MediaQuery.of(context).size.width,
              padding: EdgeInsets.fromLTRB(10, 20, 10, 20),
              child: Column(
                children: [
                  CustomTextField(
                    text: "Rs. 13,263.95",
                    upperCase: false,
                    styleFace: CustomTextStyles.titleSuperMaxBoldWhite,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  CustomTextField(
                    text: "Wallet Balance",
                    upperCase: false,
                    styleFace: CustomTextStyles.walletBalanceSubtitle,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  GestureDetector(
                    onTap: (){
                      Navigator.pushNamed(context, AppRoutes.wallet_add);
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.65,
                      height: 50,
                      decoration: BoxDecoration(
                        color: AppColors.primary,
                        borderRadius: BorderRadius.circular(10.0),
                        border: Border.all(
                          color: Colors.white,
                          width: 2.0,
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Icon(
                              Icons.add_circle,
                              color: AppColors.white,
                            ),
                            CustomTextField(
                              text: "Add Money to Wallet",
                              upperCase: false,
                              styleFace: CustomTextStyles.addWalletBalanceText,
                            )
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: CustomTextField(
                text: "Transaction History",
                styleFace: CustomTextStyles.listTitleText,
              ),
            ),
            SizedBox(
              height: 5,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Container(
                  width: 150,
                  height: 30,
                  padding: EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(10.0),
                    border: Border.all(
                      color: AppColors.primary,
                      width: 0.5,
                    ),
                  ),
                  child: Center(
                      child: CustomTextField(
                    text: "Send to bank",
                    upperCase: false,
                    styleFace: CustomTextStyles.listTitleText,
                  )),
                ),
                Container(
                  width: 150,
                  height: 30,
                  padding: EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(10.0),
                    border: Border.all(
                      color: AppColors.primary,
                      width: 0.5,
                    ),
                  ),
                  child: Center(
                      child: CustomTextField(
                    text: "Money Added",
                    upperCase: false,
                    styleFace: CustomTextStyles.listTitleText,
                  )),
                ),
              ],
            ),
            SizedBox(height: 10,),
            Expanded(
              child: ListView.builder(
                itemCount: 10,
                itemBuilder: (context, index) {
                  return getWalletCard(index);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
  getWalletCard(int index){
    return Column(
      children: [
        Container(
          width: MediaQuery.of(context).size.width,
          margin: EdgeInsets.fromLTRB(20,5,20,5),
          decoration: BoxDecoration(
            color: AppColors.white,
            borderRadius: BorderRadius.circular(10.0),
            border: Border.all(
              color: AppColors.black,
              width: 0.5,
            ),
          ),
          child: Column(
            children: <Widget>[
              Container(
                width: MediaQuery.of(context).size.width,
                padding: EdgeInsets.all(10),
                color: Colors.grey.withOpacity(0.2),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                        child: Icon(Icons.add_circle),
                        padding: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          color: AppColors.white,
                          borderRadius:
                          BorderRadius.circular(20.0),
                        )),
                    SizedBox(width: 20,),
                    Expanded(
                      child: CustomTextField(
                        text: "Money Added",
                        styleFace: CustomTextStyles.listTitleText,
                        upperCase: false,
                      ),
                    ),
                    CustomTextField(
                      text: "₹ 300",
                      styleFace: CustomTextStyles.creditAmountText,
                      upperCase: false,
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Row(
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width*.4,
                      child: CustomTextField(
                        text: "11th Jun 2023, 10:00 AM",
                        styleFace: CustomTextStyles.listTitleText,
                        upperCase: false,
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width*.4,
                      child: CustomTextField(
                        text: "Closing Balance : ₹ 13,372.96",
                        styleFace: CustomTextStyles.listTitleText,
                        upperCase: false,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.all(10),
                width: MediaQuery.of(context).size.width,
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.grey.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: CustomTextField(
                  text:
                  "Support Amt1 for device-syro_1 on 2023-06-10",
                  styleFace: CustomTextStyles.listTitleText,
                  upperCase: false,
                ),
              )
            ],
          ),
        ),

      ],
    );
  }

  navigateTab(String type) {
    if(type==AppConstants.HOME){
      Navigator.pushNamedAndRemoveUntil(context, AppRoutes.home,(Route<dynamic> route) => false);
    }
    if(type==AppConstants.TICKETS){
      Navigator.pushNamedAndRemoveUntil(context, AppRoutes.ticket_list,(Route<dynamic> route) => false);
    }
    if(type==AppConstants.RECHARGE_ISP){
      Navigator.pushNamedAndRemoveUntil(
          context, AppRoutes.recharge_isp_portal, (Route<dynamic> route) => false);
    }
  }
}
