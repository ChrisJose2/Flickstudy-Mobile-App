import 'package:flutter/material.dart';
import 'package:flutter_architecture/common/routing/app_routes.dart';
import 'package:flutter_architecture/common/widgets/text_widget.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../../../common/styles/app_colors.dart';
import '../../../../../common/styles/custom_text_styles.dart';
import '../../../../../common/utilities/constants.dart';
import '../../../../../common/widgets/custom_button.dart';
import '../../../../../common/widgets/custom_text_form_field.dart';

class LoginWithOTPView extends StatelessWidget {
  // LoginController loginController;
  LoginWithOTPView({Key? key}) : super(key: key);

  final loginFormKey = GlobalKey<FormState>();
  final mobileNumberController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              GestureDetector(
                  onTap: (){
                    Navigator.pushNamed(context, AppRoutes.register);
                  },
                  child: CustomTextField(text: "Register Your Account",upperCase: false,styleFace: CustomTextStyles.primary_14_Text_bold,)),
              CustomTextField(text: "|",styleFace: CustomTextStyles.primary_14_Text_bold),
              GestureDetector(
                  onTap: (){
                    Navigator.pushNamed(context, AppRoutes.login);
                  },
                  child: CustomTextField(text: "Login with User ID",upperCase: false,styleFace: CustomTextStyles.primary_14_Text_bold))

            ],
          ),
        ),
        body: Container(
          height: MediaQuery.of(context).size.height*.95,
          color: AppColors.white,
          padding: const EdgeInsets.fromLTRB(20.0,0,20.0,0.0),
          child: Form(
            key: loginFormKey,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Container(
                      margin: EdgeInsets.fromLTRB(0,50,0,20),
                      alignment: Alignment.center,height: 100, width: 120,
                      child:  ClipRRect(
                        borderRadius: BorderRadius.circular(15.0),
                        child: Image.asset(
                          "assets/imgs/logo.png",
                          fit: BoxFit.cover,
                        ),
                      )
                  ),
                  CustomTextField(text: "Wiom Partner ",upperCase: false,styleFace: CustomTextStyles.titleSuperMaxUltraBlack,),
                  SizedBox(height: 20,),
                  CustomTextField(text: "सपनों से ज्यादा ",upperCase: false,styleFace: CustomTextStyles.titleSuperMaxUltraBlack,),
                  SizedBox(height: 100,),
                  CustomTextFormField(

                    labelText: 'Enter your phone number',
                    hintText: 'e.g. 9876543210',
                    controller: mobileNumberController,
                    validator: validator,
                    iconWidget: const Icon(Icons.person),

                  ),


                  SizedBox(height: 40,),

                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Wrap(
                      children: [
                        CustomTextField(text: "By Continuing you accept ",upperCase: false,styleFace: CustomTextStyles.black_14_Text,),
                        CustomTextField(text: "Terms & Conditions",upperCase: false,styleFace: CustomTextStyles.black_14_Text_underline,)
                      ],
                    ),
                  ),
                  SizedBox(height: 20,),
                  CustomButton(text: 'Get OTP', onPressed: (){
                    // controller.loginUsers();
                  }),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
  String? validator(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please this field must be filled';
    }
    return null;
  }
  validateForm(){
    var validated=false;
    /*if(GetUtils.isEmail(emailController.text)){
      validated=true;
    }
    else if(!GetUtils.isEmail(emailController.text)){
      Get.snackbar("Error","Please enter valid Email",snackPosition: SnackPosition.BOTTOM);
      return false;
    }
    if(GetUtils.isLengthGreaterOrEqual(passwordController.text,6)){
      validated=true;
    }
    else{
      Get.snackbar("Error","Password should be at least 6 digit",snackPosition: SnackPosition.BOTTOM);
      return false;
    }*/
    return validated;
  }
  loginUsers() async{
    if(validateForm()) {
      bool connectivity=await AppConstants.checkInternetConnectivity();
      /*if(connectivity){
        var response = await httpProvider.loginUser(
            emailController.text, passwordController.text);
        if (response != null && response?['auth'] == true) {

          User user=User.fromJson(response);
          _saveLoginDetails(user);


        } else {
          if(response!=null && response['msg']!=null)
            Get.snackbar("Error",response?['msg'],snackPosition: SnackPosition.BOTTOM);
        }
      }else{
        _fetchLocalUser();
      }*/

    }
  }
  launchUrl(String url) async{
    var uri = Uri.parse(url);
    if (await canLaunch(uri.toString())) {
      await launch(uri.toString());
    } else {
      throw 'Could not launch ${uri.toString()}';
    }
  }
}
