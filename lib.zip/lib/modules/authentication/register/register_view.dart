import 'package:flutter/material.dart';
import 'package:flutter_architecture/common/routing/app_routes.dart';
import 'package:flutter_architecture/common/widgets/text_widget.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../../../common/styles/app_colors.dart';
import '../../../../../common/styles/custom_text_styles.dart';
import '../../../../../common/utilities/constants.dart';
import '../../../../../common/widgets/custom_button.dart';
import '../../../../../common/widgets/custom_text_form_field.dart';

class RegisterView extends StatelessWidget {
  // LoginController loginController;
  RegisterView({Key? key}) : super(key: key);

  final loginFormKey = GlobalKey<FormState>();
  final nameController = TextEditingController();
  final mobileController = TextEditingController();
  final addressController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Container(
        color: AppColors.white,
        padding: const EdgeInsets.fromLTRB(30.0,0,30.0,0.0),
        height: MediaQuery.of(context).size.height*.10,
        child: Column(
          children: [
            Padding(

              padding: const EdgeInsets.only(left:5.0,right: 5),
              child: Divider(height: 1,),
            ),
            SizedBox(height: 10,),
            GestureDetector(
              onTap: (){
                launchUrl("tel: 8880322222");
              },
              child: Row(
                children: [
                  CustomTextField(text: "Get help - ",upperCase: false,styleFace: CustomTextStyles.black_14_Text,),
                  CustomTextField(text: "8880322222",upperCase: false,styleFace: CustomTextStyles.primary_14_Text,),
                ],
              ),
            ),

          ],
        ),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height*.90,
        color: AppColors.white,
        padding: const EdgeInsets.fromLTRB(20.0,0,20.0,0.0),
        child: Form(
          key: loginFormKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                    margin: EdgeInsets.fromLTRB(0,MediaQuery.of(context).size.height*0.2,0,10),
                    alignment: Alignment.center,height: 100, width: 120,
                    child:  ClipRRect(
                      borderRadius: BorderRadius.circular(15.0),
                      child: Image.asset(
                        "assets/imgs/logo.png",
                        fit: BoxFit.cover,
                      ),
                    )
                ),
                CustomTextFormField(

                  labelText: 'Enter Name',

                  controller: nameController,
                  validator: validator,
                  iconWidget: const Icon(Icons.person),

                ),
                CustomTextFormField(

                  labelText: 'Enter Phone Number',
                  controller: mobileController,
                  validator: validator,
                  maxLines: 1,
                  iconWidget: const Icon(Icons.vpn_key),
                  obscureText: true,

                ),
                CustomTextFormField(

                  labelText: 'Enter Address',
                  controller: addressController,
                  validator: validator,
                  maxLines: 1,
                  iconWidget: const Icon(Icons.location_on),
                  obscureText: true,

                ),
                Padding(

                  padding: const EdgeInsets.only(left:25.0,right: 25),
                  child: CustomButton(text: 'Register', onPressed: (){
                    // controller.loginUsers();
                  }),
                ),
                SizedBox(height: 20,),
                GestureDetector(
                    onTap: (){
                      Navigator.pop(context);
                    },
                    child: CustomTextField(text: "Already have an account ? Login",upperCase: false,styleFace: CustomTextStyles.primary_14_Text,)),

              ],
            ),
          ),
        ),
      ),
    );
  }
  String? validator(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please this field must be filled';
    }
    return null;
  }
  validateForm(){
    var validated=false;
    /*if(GetUtils.isEmail(emailController.text)){
      validated=true;
    }
    else if(!GetUtils.isEmail(emailController.text)){
      Get.snackbar("Error","Please enter valid Email",snackPosition: SnackPosition.BOTTOM);
      return false;
    }
    if(GetUtils.isLengthGreaterOrEqual(passwordController.text,6)){
      validated=true;
    }
    else{
      Get.snackbar("Error","Password should be at least 6 digit",snackPosition: SnackPosition.BOTTOM);
      return false;
    }*/
    return validated;
  }
  loginUsers() async{
    if(validateForm()) {
      bool connectivity=await AppConstants.checkInternetConnectivity();
      /*if(connectivity){
        var response = await httpProvider.loginUser(
            emailController.text, passwordController.text);
        if (response != null && response?['auth'] == true) {

          User user=User.fromJson(response);
          _saveLoginDetails(user);


        } else {
          if(response!=null && response['msg']!=null)
            Get.snackbar("Error",response?['msg'],snackPosition: SnackPosition.BOTTOM);
        }
      }else{
        _fetchLocalUser();
      }*/

    }
  }
  launchUrl(String url) async{
    var uri = Uri.parse(url);
    if (await canLaunch(uri.toString())) {
      await launch(uri.toString());
    } else {
      throw 'Could not launch ${uri.toString()}';
    }
  }
}
