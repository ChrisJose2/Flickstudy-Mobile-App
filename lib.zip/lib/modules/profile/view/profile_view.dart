import 'dart:io';
import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_architecture/common/widgets/app_bar.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:ui' as ui;

import '../../../common/routing/app_routes.dart';
import '../../../common/styles/app_colors.dart';
import '../../../common/styles/custom_text_styles.dart';
import '../../../common/widgets/text_widget.dart';
class ProfileView extends StatelessWidget{
  ProfileView({Key? key}) : super(key: key);
  @override

  final GlobalKey globalKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarView(title:"Profile" ),
      body: Container(
        color: AppColors.white,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              RepaintBoundary(
                 key:globalKey,
                child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Container(
                    height: 180,
                    width: MediaQuery.of(context).size.width,

                    decoration: const BoxDecoration(
                        color: AppColors.primaryLight,
                        //could change this to Color(0xFF737373),
                        shape: BoxShape.rectangle,
                        borderRadius: BorderRadius.all(Radius.circular(15))),
                    child: Row(
                      children: [
                        Container(
                            width: 120,
                            height: 180,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.all(Radius.circular(15)),
                              image: DecorationImage(
                                image: AssetImage('assets/imgs/vc-bg.png'),

                                fit: BoxFit.cover,
                              ),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Image.asset(height: 25,width: 25,'assets/imgs/wiom_vc.png'),
                            )
                          // your child widgets here
                        ),

                        Container(
                          margin: EdgeInsets.fromLTRB(10, 20, 5, 0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: CustomTextField(text: "Anugrah Verma",color: AppColors.primary,styleFace: CustomTextStyles.titleMaxBold,),
                              ),
                              Padding(
                                  padding: const EdgeInsets.all(5.0),
                                  child: Row(
                                    children: [
                                      Icon(Icons.phone,size: 15 ),
                                      SizedBox(width: 20,),
                                      CustomTextField(text: "+91-8559859173",color: AppColors.primary,),
                                    ],
                                  )),
                              Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: Row(
                                  children: [
                                    Icon(Icons.people,size: 15 ),
                                    SizedBox(width: 20,),
                                    CustomTextField(text: "Balaji Networks ",color: AppColors.primary,),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: CustomTextField(text: "Contact me for Internet",upperCase: false,
                                  color: AppColors.primary,styleFace: CustomTextStyles.semiBold,),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: CustomTextField(text: "WIOM Certified Partner",
                                  color: AppColors.primary,styleFace: CustomTextStyles.visitingCardsubtitle,),
                              ),


                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
              GestureDetector(
                onTap: (){
                  capturePng();
                },
                child: Center(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          child: CustomTextField(text:" Share your visiting card",upperCase: false,styleFace: CustomTextStyles.visitingCardsubtitle,),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          child: Image.network(height: 30,'https://seeklogo.com/images/W/whatsapp-logo-33F6A82887-seeklogo.com.png'),
                        ),
                      )
                    ],
                  ),
                ),
              ),Divider(thickness: 1,color: AppColors.primary,),
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: Row(
                  children: [
                    Icon(Icons.person_2_outlined,color: AppColors.primary ,),
                    SizedBox(width: 20,),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomTextField(text: "Basic details",styleFace: CustomTextStyles.titleText,),
                        SizedBox(height: 5,),
                        CustomTextField(text: "Your name, address and password",upperCase: false,styleFace: CustomTextStyles.subtitleText,)
                      ],
                    ),

                  ],
                ),
              ),
              GestureDetector(
                onTap: (){
                  _openLanugageBottomSheet(context);
                },
                child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.language,color: AppColors.primary ,),
                      SizedBox(width: 20,),
                      Column(

                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomTextField(text: "Change Language",styleFace: CustomTextStyles.titleText,),
                          SizedBox(height: 5,),
                          CustomTextField(text: "Choose your preferred language",upperCase: false,styleFace: CustomTextStyles.subtitleText,)
                        ],
                      ),

                    ],
                  ),
                ),
              ),
              GestureDetector(
                onTap: (){
                  Navigator.pushNamed(context, AppRoutes.manage_team_member);
                },
                child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.group,color: AppColors.primary ,),
                      SizedBox(width: 20,),
                      Column(

                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomTextField(text: "Manage Team Members",styleFace: CustomTextStyles.titleText,),
                          SizedBox(height: 5,),
                          CustomTextField(text: "Manage your team members",upperCase: false,styleFace: CustomTextStyles.subtitleText,)
                        ],
                      ),

                    ],
                  ),
                ),
              ),
              Divider(thickness: 1,color: AppColors.primary,),
              GestureDetector(
                onTap: (){
                    launchUrl("https://wiom.in/");
                },
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(15.0,5,0,5),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.file_present_outlined,color: AppColors.primary ,),
                      SizedBox(width: 20,),
                      CustomTextField(text: "Terms & Conditions",upperCase: false,styleFace: CustomTextStyles.titleText,),

                    ],
                  ),
                ),
              ),
              GestureDetector(
                onTap: (){
                  launchUrl("https://wiom.in/");
                },
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(15.0,5,0,5),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.info_outline,color: AppColors.primary ,),
                      SizedBox(width: 20,),
                      CustomTextField(text: "Privacy Policy",upperCase: false,styleFace: CustomTextStyles.titleText,),

                    ],
                  ),
                ),
              ),
              GestureDetector(
                onTap: (){
                  Navigator.pushNamed(context, AppRoutes.faq);
                },
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(15.0,5,0,5),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.help_outline,color: AppColors.primary ,),
                      SizedBox(width: 20,),
                      CustomTextField(text: "FAQs",upperCase: false,styleFace: CustomTextStyles.titleText,),

                    ],
                  ),
                ),
              ),
              Divider(thickness: 1,color: AppColors.primary,),
              GestureDetector(
                onTap: (){
                  // controller.logout();
                  _showLogoutBottomSheet(context);
                },
                child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.logout,color: Colors.red ,),
                      SizedBox(width: 20,),
                      Column(

                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomTextField(text: "Logout",styleFace: CustomTextStyles.redText,),
                          SizedBox(height: 5,),
                          CustomTextField(text: "Logoff your session",upperCase: false,styleFace: CustomTextStyles.subtitleText,)
                        ],
                      ),

                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
  void _showLogoutBottomSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.0)),
      ),
      builder: (BuildContext context) {
        return Container(
          padding: EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              SizedBox(height: 16),
              Text(
                'Are you sure you want to logout ?',
                style: CustomTextStyles.black_14_Text,
              ),
              SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [

                OutlinedButton(
                  onPressed: () {
                    // Action for the "No" button
                    Navigator.pop(context); // Close the bottom sheet
                  },
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(
                      color: AppColors.primary,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(40,5,40,5),
                    child: CustomTextField(
                      text: "No",upperCase: false, styleFace: CustomTextStyles.primary_14_Text,),
                  ),
                ),
                ElevatedButton(
                    onPressed: () {
                      // Action for the "Yes" button
                      Navigator.pop(context);
                      Navigator.pushNamedAndRemoveUntil(
                          context, AppRoutes.login_with_otp, (Route<dynamic> route) => false);
                    },
                    style: ElevatedButton.styleFrom(
                      primary: AppColors.primary,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(40,5,40,5),

                      child: CustomTextField(
                        text: "Yes",upperCase: false, styleFace: CustomTextStyles.white_14_Text,),
                    ),
                  ),
              ],)
            ],
          ),
        );
      },
    );
  }
  void capturePng() async {
    final RenderRepaintBoundary boundary = globalKey.currentContext?.findRenderObject() as RenderRepaintBoundary;
    if (boundary.debugNeedsPaint) {
      Timer(Duration(seconds: 2), () => capturePng());
      return null;
    }
    final directory = (await getExternalStorageDirectory())?.path;

    final ui.Image image = await boundary.toImage();

    final ByteData? byteData = await image.toByteData(format: ui.ImageByteFormat.png);

    final Uint8List pngBytes = byteData?.buffer.asUint8List() as Uint8List;
    File imgFile = File('$directory/screenshot.png');
    imgFile.writeAsBytes(pngBytes);
    final RenderBox box = globalKey.currentContext?.findRenderObject() as RenderBox;
    Share.shareFiles(['$directory/screenshot.png'],
        subject: 'Share ScreenShot',
        text: 'Please find my visiting card',
        sharePositionOrigin: box.localToGlobal(Offset.zero) & box.size
    );
  }
  launchUrl(String url) async{
    var uri = Uri.parse(url);
    if (await canLaunch(uri.toString())) {
      await launch(uri.toString());
    } else {
      throw 'Could not launch ${uri.toString()}';
    }
 }
  void _openLanugageBottomSheet(context) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        builder: (BuildContext bc) {
          return SingleChildScrollView(
            child: Container(
              padding: const EdgeInsets.fromLTRB(20, 30, 20, 30),
              decoration: BoxDecoration(
                  color: Colors.white,
                  //could change this to Color(0xFF737373),
                  shape: BoxShape.rectangle,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(15.0),
                      topRight: Radius.circular(15.0))),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(10, 0, 0, 10),
                    child: Container(
                        child: Opacity(
                          opacity: 0.7,
                          child: CustomTextField(text: "Choose Language",),
                        )),
                  ),
                  getLanguageCard("English",context),
                  getLanguageCard("हिंदी",context),


                ],
              ),
            ),
          );
        });
  }
  Widget getLanguageCard(cardItem,context){
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [

          Expanded(
            child: Padding(
                padding: const EdgeInsets.all(4.0),
                child: CustomTextField(text: cardItem,upperCase: false,)
            ),
          ),
          SizedBox(width: 20,),
          GestureDetector(
              onTap: (){

              },
              child: Icon(Icons.check,color: AppColors.primary,)),

        ],
      ),
    );
  }
}
