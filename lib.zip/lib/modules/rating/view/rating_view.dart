import 'package:flutter/material.dart';
import 'package:flutter_architecture/common/widgets/custom_button.dart';
import 'package:flutter_architecture/common/widgets/text_widget.dart';
import 'package:reactive_forms/reactive_forms.dart';
import '../../../common/styles/app_colors.dart';
import '../../../common/styles/custom_text_styles.dart';
import '../../../common/widgets/app_bar.dart';
import '../../../common/widgets/reactive_field_widget.dart';

class RatingView extends StatefulWidget {
  @override
  RatingViewState createState() => RatingViewState();
}
class RatingViewState extends State<RatingView> {

  double extraHeight=0;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBarView(title: "Current Rating"),
        body: Stack(
          children: [
        Container(

        color: AppColors.black,
        height: 250,),
            SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: EdgeInsets.all(20),
                    height: 350+extraHeight,
                    padding: EdgeInsets.all(10),
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      color: AppColors.white,
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.5),
                          spreadRadius: 2,
                          blurRadius: 5,
                          offset: Offset(0, 3), // changes the shadow position
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Icon(Icons.star),
                            SizedBox(
                              width: 10,
                            ),
                            CustomTextField(
                              text: "4.88",
                              styleFace: CustomTextStyles.titleSuperMaxBoldPrimary,
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            GestureDetector(
                                onTap: (){
                                  if(extraHeight==200)
                                    extraHeight=0;
                                  else
                                    extraHeight=200;
                                  setState(() {

                                  });
                                },
                                child: Icon(extraHeight>0?Icons.keyboard_arrow_up:Icons.keyboard_arrow_down,color: AppColors.primary,size: 18,))
                          ],
                        ),
                        SizedBox(height: 30,),
                        extraHeight==200?Container(
                          height: 200,
                          width: MediaQuery.of(context).size.width*.8,
                          decoration: BoxDecoration(
                            color: AppColors.grey,
                            borderRadius: BorderRadius.circular(15)
                          ),
                          child: Column(children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                children: [
                                CustomTextField(text: "5",styleFace: CustomTextStyles.listTitleTextBold ,),

                                Row(
                                  children: [
                                    Container(width: MediaQuery.of(context).size.width*0.6,
                                    height: 20,
                                    decoration: BoxDecoration(
                                      color: AppColors.primary
                                    ),),
                                    Container(width: MediaQuery.of(context).size.width*0.1,
                                      height: 20,
                                      decoration: BoxDecoration(
                                          color: AppColors.white
                                      ),)
                                  ],
                                ),

                              ],),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                children: [
                                  CustomTextField(text: "4",styleFace: CustomTextStyles.listTitleTextBold ,),

                                  Row(
                                    children: [
                                      Container(width: MediaQuery.of(context).size.width*0.5,
                                        height: 20,
                                        decoration: BoxDecoration(
                                            color: AppColors.primary
                                        ),),
                                      Container(width: MediaQuery.of(context).size.width*0.2,
                                        height: 20,
                                        decoration: BoxDecoration(
                                            color: AppColors.white
                                        ),)
                                    ],
                                  ),

                                ],),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                children: [
                                  CustomTextField(text: "3",styleFace: CustomTextStyles.listTitleTextBold ,),

                                  Row(
                                    children: [
                                      Container(width: MediaQuery.of(context).size.width*0.4,
                                        height: 20,
                                        decoration: BoxDecoration(
                                            color: AppColors.primary
                                        ),),
                                      Container(width: MediaQuery.of(context).size.width*0.3,
                                        height: 20,
                                        decoration: BoxDecoration(
                                            color: AppColors.white
                                        ),)
                                    ],
                                  ),

                                ],),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                children: [
                                  CustomTextField(text: "2",styleFace: CustomTextStyles.listTitleTextBold ,),

                                  Row(
                                    children: [
                                      Container(width: MediaQuery.of(context).size.width*0.3,
                                        height: 20,
                                        decoration: BoxDecoration(
                                            color: AppColors.primary
                                        ),),
                                      Container(width: MediaQuery.of(context).size.width*0.4,
                                        height: 20,
                                        decoration: BoxDecoration(
                                            color: AppColors.white
                                        ),)
                                    ],
                                  ),

                                ],),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                children: [
                                  CustomTextField(text: "1",styleFace: CustomTextStyles.listTitleTextBold ,),

                                  Row(
                                    children: [
                                      Container(width: MediaQuery.of(context).size.width*0.2,
                                        height: 20,
                                        decoration: BoxDecoration(
                                            color: AppColors.primary
                                        ),),
                                      Container(width: MediaQuery.of(context).size.width*0.5,
                                        height: 20,
                                        decoration: BoxDecoration(
                                            color: AppColors.white
                                        ),)
                                    ],
                                  ),

                                ],),
                            ),

                          ],),
                        ):Container(),
                        getVerticalBar(488, 473, 500),

                      ],
                    ),
                  ),

                  Container(

                      margin: EdgeInsets.fromLTRB(40,20,20,0),
                    child: Row(
                      children: [

                        Expanded(
                          child: CustomTextField(
                            text: "₹ 6,851",
                            styleFace: CustomTextStyles.titleSuperMaxBoldBlack,
                          ),
                        ),
                        Container(
                          width: 100,
                          height: 30,
                          padding: EdgeInsets.all(5),
                          child: Center(child: CustomTextField(text: "Earn More >",upperCase: false,styleFace: CustomTextStyles.white_12_Text,)),
                          decoration: BoxDecoration(
                            color: AppColors.primary,
                            borderRadius: BorderRadius.circular(15)
                          ),
                        )
                      ],

                    ),
                  ),
                  Container(
                      margin: EdgeInsets.fromLTRB(40,10,20,10),
                      child: CustomTextField(text: "Total Bonus Earned",upperCase: false,styleFace: CustomTextStyles.listTitleText,)),
                  Container(
                      margin: EdgeInsets.fromLTRB(40,10,20,0),
                      child: CustomTextField(text: "Bonus Earned",upperCase: false,styleFace: CustomTextStyles.listTitleTextBold,)),
                  Container(
                      margin: EdgeInsets.fromLTRB(40,0,20,10),
                      child: CustomTextField(text: "(per connection per month)",upperCase: false,styleFace: CustomTextStyles.listTitleText,)),


                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget getVerticalBar(int value1, int value2, int value3) {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Stack(
        children: [
          Container(
              margin: EdgeInsets.only(left: 0),
              height: 215,
              width: 1,
              color: AppColors.grey,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Column(
                children: [
                  Row(
                    children: [
                      Icon(Icons.star,size: 15,),
                      SizedBox(
                        width: 2,
                      ),
                      CustomTextField(text: (value1 / 100).toString()),
                    ],
                  ),
                  SizedBox(height: 5,),
                  Container(
                    height: value1 - 300,
                    width: 50,
                    color: AppColors.primary,
                  ),
                  SizedBox(height: 10,),
                  CustomTextField(text: "My Rating",upperCase: false,styleFace: CustomTextStyles.black_14_Text_bold,)
                ],
              ),
              Column(
                children: [
                  Row(
                    children: [
                      Icon(Icons.star,size: 15),
                      SizedBox(
                        width: 2,
                      ),
                      CustomTextField(text: (value2 / 100).toString()),
                    ],
                  ),
                  SizedBox(height: 5,),
                  Container(
                    height: value2 - 300,
                    width: 50,
                    color: AppColors.black,
                  ),
                  SizedBox(height: 10,),
                  CustomTextField(text: "Average",upperCase: false,styleFace: CustomTextStyles.black_14_Text)
                ],
              ),
              Column(
                children: [
                  Row(
                    children: [
                      Icon(Icons.star,size: 15),
                      SizedBox(
                        width: 2,
                      ),
                      CustomTextField(text: (value3 / 100).toString()),
                    ],
                  ),
                  SizedBox(height: 5,),
                  Container(
                    height: value3 - 300,
                    width: 50,
                    color: AppColors.black,
                  ),
                  SizedBox(height: 10,),
                  CustomTextField(text: "Highest",upperCase: false,styleFace: CustomTextStyles.black_14_Text,)
                ],
              ),
            ],
          ),
          Container(
              margin: EdgeInsets.only(top: 220),
              child: Divider(height: 2,thickness:1,color: AppColors.grey,))
        ],
      ),
    );
  }
}
