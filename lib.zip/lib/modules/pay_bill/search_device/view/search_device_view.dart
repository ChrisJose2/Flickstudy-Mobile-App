import 'package:flutter/material.dart';
import 'package:flutter_architecture/common/routing/app_routes.dart';
import 'package:flutter_architecture/common/styles/app_colors.dart';
import 'package:flutter_architecture/common/styles/custom_text_styles.dart';
import 'package:flutter_architecture/common/utilities/constants.dart';
import 'package:flutter_architecture/common/widgets/app_bar.dart';
import 'package:flutter_architecture/common/widgets/bottom_navigation.dart';
import 'package:flutter_architecture/common/widgets/custom_button.dart';
import 'package:flutter_architecture/common/widgets/custom_text_form_field.dart';
import 'package:flutter_architecture/common/widgets/text_widget.dart';


class SearchDeviceView extends StatefulWidget {
  const SearchDeviceView();

  @override
  SearchDeviceState createState() => SearchDeviceState();
}

class SearchDeviceState extends State<SearchDeviceView> {
  TextEditingController amountController=TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarView(title: "Pay Bill"),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.max,
            children: [
              Expanded(
                child: Container(
                  margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomTextFormField(iconWidget:const Icon(Icons.phone_android),labelText: "Enter Registered No. OR Device ID", controller: amountController),

                     Container(
                         margin: EdgeInsets.fromLTRB(10, 0, 0, 0),
                         child: CustomTextField(text: "Invalid Device ID",styleFace: CustomTextStyles.formFieldMandatory,))
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10,),
              Align(
                alignment: Alignment.bottomCenter,
                child: CustomButton(text: 'Continue', onPressed: (){

                  //controller.loginUsers();
                }),

              ),
              SizedBox(height: 10,),
            ],
          ),
        ),
      ),
    );
  }

  navigateTab(String type) {
    /*if(type==AppConstants.HOME){
      selectedType=AppConstants.HOME;
    }
    if(type==AppConstants.TICKETS){
      selectedType=AppConstants.TICKETS;
    }*/
    if (type == AppConstants.WALLET) {
      Navigator.pushNamed(context, AppRoutes.wallet_list);
    }
    /*if(type==AppConstants.RECHARGE_ISP){
      selectedType=AppConstants.RECHARGE_ISP;
    }*/
  }
  setAmount(String value){
    amountController.text.isEmpty?amountController.text=value:amountController.text=(int.parse(amountController.text)+int.parse(value)).toString();
  }
}
