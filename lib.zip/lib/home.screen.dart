import 'dart:async';
import 'dart:math' as math; // import this

import 'package:avatar_glow/avatar_glow.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_architecture/common/routing/app_routes.dart';
import 'package:flutter_architecture/common/utilities/constants.dart';
import 'package:flutter_architecture/common/widgets/app_bar.dart';
import 'package:flutter_architecture/language.dart';
import 'package:flutter_architecture/user.viewmodel.dart';
import 'package:hawk_fab_menu/hawk_fab_menu.dart';
import 'package:provider/provider.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import 'common/styles/app_colors.dart';
import 'common/styles/custom_text_styles.dart';
import 'common/widgets/bottom_navigation.dart';
import 'common/widgets/custom_text_form_field.dart';
import 'common/widgets/text_widget.dart';

class HomeScreen extends StatefulWidget {
  @override
  HomeScreenState createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Timer _timer;
  Color _currentColor = Colors.pink;
  final HawkFabMenuController hawkFabMenuController = HawkFabMenuController();
  final List<String> imageArr = [
    'assets/imgs/faq.jpg',
    'assets/imgs/faq.jpg',
    'assets/imgs/faq.jpg'
  ];
  //${AppLocalizations.of(context)!.helloWorld
  String selectedType = AppConstants.HOME;
  final List<String> menuItems = [
    "Overdue",
    "Installations",
    "Overdue",
    "Installations",
    "Overdue",
    "Installations"
  ];
  @override
  Widget build(BuildContext context) {
    final userViewModel = Provider.of<UserViewModel>(context);
    final languageViewModel = Provider.of<Language>(context);
    return Scaffold(
      appBar: getAppBar(context),
      bottomNavigationBar: BottomNavigationBarView(
          selected: selectedType,
          onHomePressed: () => navigateTab(AppConstants.HOME),
          onTicketPressed: () => navigateTab(AppConstants.TICKETS),
          onWalletPressed: () => navigateTab(AppConstants.WALLET),
          onRechargePressed: () => navigateTab(AppConstants.RECHARGE_ISP)),
      body: HawkFabMenu(
        icon: AnimatedIcons.add_event,
        iconColor: AppColors.white,
        hawkFabMenuController: hawkFabMenuController,
        items: [
          HawkFabMenuItem(
              label: 'Add Money to Wallet',
              ontap: () {
                Navigator.pushNamed(context, AppRoutes.wallet_add);
              },
              icon: const Icon(
                Icons.credit_card,
                color: AppColors.primary,
              ),
              color: AppColors.white,
              labelColor: AppColors.primary,
              labelBackgroundColor: AppColors.white),
          HawkFabMenuItem(
              label: 'Pay Bill',
              ontap: () {

                Navigator.pushNamed(context, AppRoutes.pay_bill_search_device);
              },
              icon: const Icon(
                Icons.money,
                color: AppColors.primary,
              ),
              color: AppColors.white,
              labelColor: AppColors.primary,
              labelBackgroundColor: AppColors.white),
        ],
        body: SingleChildScrollView(
          child: Container(
            margin: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                getPriorityTaskCard(1),
                SizedBox(height: 10,),
                /*AnimatedContainer(
                  height: 100,
                  duration: Duration(seconds: 2),
                  color: _currentColor,
                  curve: Curves.easeInOut,
                ),
                SizedBox(
                  height: 20,
                ),*/
                GestureDetector(
                  onTap: () {
                    _openModalBottomSheet(context);
                  },
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(7, 0, 5, 0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomTextField(text: 'Filter by User'),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * 0.9,
                          height: 45,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10.0),
                              border: Border.all(
                                color: AppColors.background,
                                width: 1.0,
                              )),
                          child: Container(
                            color: AppColors.background,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Container(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      height: 5,
                                    ),
                                    Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Icon(Icons.person, size: 14),
                                        SizedBox(
                                          width: 18,
                                        ),
                                        Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              .65,
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              CustomTextField(
                                                  text: 'Ramesh Pareekh'),
                                            ],
                                          ),
                                        ),
                                        SizedBox(width: 10),
                                        Icon(
                                          Icons.arrow_drop_down,
                                          size: 15,
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 260,
                  child: GridView.count(
                      crossAxisCount: 3,
                      children: List.generate(6, (index) {
                        return GestureDetector(
                          onTap: () {
                            //_openModalBottomSheet(controller.menuItems[index],context);
                          },
                          child: Container(
                            height: 50,
                            child: Card(
                              elevation: 5,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  CustomTextField(
                                    text: (index * 10).toString(),
                                    styleFace: CustomTextStyles.titleMaxBold,
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  CustomTextField(
                                    text: menuItems[index],
                                    upperCase: false,
                                    styleFace: CustomTextStyles.listTitleText,
                                  )
                                ],
                              ),
                            ),
                          ),
                        );
                      })),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10.0, bottom: 5),
                  child: CustomTextField(text: "FAQs"),
                ),
                Container(
                    height: 200.0,
                    child: CarouselSlider(
                      options: CarouselOptions(height: 180.0),
                      items: [0, 1, 2].map((i) {
                        return Builder(
                          builder: (BuildContext context) {
                            return Container(
                                width: MediaQuery.of(context).size.width,
                                margin: EdgeInsets.symmetric(horizontal: 5.0),
                                decoration: BoxDecoration(
                                    color: AppColors.white,
                                    borderRadius: BorderRadius.circular(10.0),
                                    border: Border.all(
                                      color: AppColors.background,
                                      width: 1.0,
                                    )),
                                child: Image.asset(imageArr[i]));
                          },
                        );
                      }).toList(),
                    )),
                SizedBox(
                  height: 10,
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10.0, bottom: 5),
                  child: CustomTextField(text: "Router Status"),
                ),
                Row(
                  children: [
                    getRouterCard(RouterType.IN_USE),
                    getRouterCard(RouterType.READY_TO_USE),
                  ],
                ),
                Row(
                  children: [
                    getRouterCard(RouterType.TO_BE_PICKED),
                    getRouterCard(RouterType.TO_RETURN),
                  ],
                ),
                
              ],
            ),
          ),
        ), /*drawer: MenuListView()*/
      ),
    );
  }
  getPriorityTaskCard(int index){
    return Column(
      children: [
        Container(
          width: MediaQuery.of(context).size.width,
          margin: EdgeInsets.fromLTRB(0,10,0,10),
          decoration: BoxDecoration(
            color: AppColors.white,
            borderRadius: BorderRadius.circular(15.0),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                spreadRadius: 2,
                blurRadius: 5,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            children: <Widget>[
              Container(
                width: MediaQuery.of(context).size.width,
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.primaryLight,
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(15),topRight: Radius.circular(15)),

                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const AvatarGlow(
                        endRadius: 15,
                        animate: true,
                        child: Material(
                          elevation: 8.0,
                          shape: CircleBorder(),
                          child: CircleAvatar(
                            backgroundColor: AppColors.yellow,
                            radius: 5,
                          ),
                        )),
                        SizedBox(width: 20,),
                        Expanded(
                          child: CustomTextField(
                            text: "Rajat Solanki",
                            styleFace: CustomTextStyles.listTitleText,
                            upperCase: false,
                          ),
                        ),
                        Icon(Icons.call,color: AppColors.primary,)
                      ],
                    ),
                    Row(
                      children: [
                        Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            margin: EdgeInsets.only(left: 50),
                            height: 20,
                            width: 50,
                            decoration: BoxDecoration(
                                color: AppColors.primary,
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Center(child: CustomTextField(text: "New",upperCase: false,styleFace: CustomTextStyles.white_14_Text,)),
                          ),
                        ),
                        SizedBox(width: 10,),
                        Image.asset("assets/imgs/router_24px.png",height: 20,),
                        SizedBox(width: 10,),
                        CustomTextField(text: "ID: ABC123")
                      ],
                    )
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 15.0,right: 15.0,top: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Image.asset("assets/imgs/internet_not_working.png",height: 15,width: 15,),
                    SizedBox(width: 20,),
                    Container(
                      child: CustomTextField(
                        text: "Internet is not working",
                        styleFace: CustomTextStyles.listTitleText,
                        upperCase: false,
                      ),
                    )
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 15.0,right: 15.0,top: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.access_time,color: AppColors.primary,),
                        SizedBox(width: 10,),
                        CustomTextField(text: "Later",upperCase: false,styleFace: CustomTextStyles.primary_14_Text,)
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        height: 40,
                        width: 40,
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          borderRadius: BorderRadius.circular(50)
                        ),
                        child: Transform(

                            alignment: Alignment.center,
                            transform: Matrix4.rotationY(math.pi),
                            child: Icon(Icons.reply,color: AppColors.white,)),
                      ),
                    ),
                  ],
                ),
              )

            ],
          ),
        ),

      ],
    );
  }
  getRouterCard(String routerType) {
    return Container(
      width: MediaQuery.of(context).size.width * 0.4,
      margin: const EdgeInsets.all(8.0),
      padding: const EdgeInsets.all(8.0),
      decoration: BoxDecoration(
        color: Colors.grey.withOpacity(.1),
        borderRadius: BorderRadius.circular(10.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            spreadRadius: 2,
            blurRadius: 5,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
              margin: EdgeInsets.fromLTRB(8, 10, 0, 0),
              child: Icon(Icons.wifi),
              padding: EdgeInsets.all(5),
              decoration: BoxDecoration(
                color: AppColors.white,
                borderRadius: BorderRadius.circular(20.0),
              )),
          SizedBox(height: 8),
          Container(
              margin: EdgeInsets.fromLTRB(10, 10, 0, 0),
              child: CustomTextField(
                text: "76",
                styleFace: CustomTextStyles.titleMaxBoldBlack,
              )),
          SizedBox(height: 8),
          Row(
            children: [
              const AvatarGlow(
                  endRadius: 15,
                  animate: true,
                  child: Material(
                    elevation: 8.0,
                    shape: CircleBorder(),
                    child: CircleAvatar(
                      backgroundColor: AppColors.primary,
                      radius: 5,
                    ),
                  )),
              CustomTextField(
                text: "In Use",
                upperCase: false,
                styleFace: CustomTextStyles.routerStatusText,
              ),
            ],
          )
        ],
      ),
    );
  }

  navigateTab(String type) {
    selectedType = type;


    if(type==AppConstants.TICKETS){
      Navigator.pushNamedAndRemoveUntil(
          context, AppRoutes.ticket_list, (Route<dynamic> route) => false);
    }
    if (type == AppConstants.WALLET) {
      Navigator.pushNamedAndRemoveUntil(
          context, AppRoutes.wallet_list, (Route<dynamic> route) => false);
    }
    if(type==AppConstants.RECHARGE_ISP){
      Navigator.pushNamedAndRemoveUntil(
          context, AppRoutes.recharge_isp_portal, (Route<dynamic> route) => false);
    }
  }

  getAppBar(context) {
    return AppBar(
        elevation: 0,
        backgroundColor: AppColors.black,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            GestureDetector(
              onTap: () {
                Navigator.pushNamed(context, AppRoutes.profile);
              },
              child: Container(
                height: 50,
                width: 50,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15.0),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(3.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(15.0),
                    child: Image.asset(
                      "assets/imgs/logo.png",
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 20,
            ),
            Expanded(
              child: GestureDetector(
                onTap: () {
                  Navigator.pushNamed(context, AppRoutes.profile);
                },
                child: CustomTextField(
                  styleFace: CustomTextStyles.titleBarText,
                  text: "Hi, Ramesh",
                  upperCase: false,
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                Navigator.pushNamed(context, AppRoutes.notification_list);
              },
              child: Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 15, 0),
                  child: Stack(
                    children: [
                      Icon(
                        Icons.notifications,
                        color: AppColors.primary,
                      ),
                      Positioned(
                          top: 0,
                          right: 0,
                          child: Container(
                              padding: EdgeInsets.all(2),
                              decoration: BoxDecoration(
                                color: AppColors.primaryLight,
                                shape: BoxShape.circle,
                              ),
                              child: CustomTextField(text: "1",styleFace: CustomTextStyles.badgeText,
                              ))),
                    ],
                  )),
            ),
            SizedBox(
              width: 10,
            ),
            GestureDetector(
              onTap: () {
                Navigator.pushNamed(context, AppRoutes.rating);
              },
              child: Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                  padding: EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: AppColors.primary)
                  ),

                  child: Row(
                    children: [
                      Icon(
                        Icons.star,
                        color: AppColors.primary,
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      CustomTextField(
                        styleFace: CustomTextStyles.titleBarText,
                        text: "4.5 ",
                      ),
                    ],
                  )),
            ),
          ],
        ),
        centerTitle: false);
  }

  void _openModalBottomSheet(context) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        builder: (BuildContext bc) {
          return SingleChildScrollView(
            child: Container(
              padding: const EdgeInsets.fromLTRB(10, 30, 10, 30),
              decoration: const BoxDecoration(
                  color: AppColors.white,
                  //could change this to Color(0xFF737373),
                  shape: BoxShape.rectangle,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(15.0),
                      topRight: Radius.circular(15.0))),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                    child: CustomTextFormField(
                      controller: new TextEditingController(),
                      labelText: 'Search User',
                      // controller: controller.searchEditingController,
                      onChanged: (value) {
                        // controller.filterData(formComponent,value);
                      },
                    ),
                  ),
                  for (int i = 0; i < 4; i++)
                    GestureDetector(
                      onTap: () {
                        // controller.update();
                        Navigator.pop(context);
                      },
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(10, 5, 0, 0),
                        child: Container(
                          decoration: BoxDecoration(
                              color: AppColors.white,
                              //could change this to Color(0xFF737373),
                              shape: BoxShape.rectangle,
                              borderRadius: BorderRadius.circular(20)),
                          child: Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: CustomTextField(
                              text: 'User $i',
                            ),
                          ),
                        ),
                      ),
                    )
                ],
              ),
            ),
          );
        });
  }

  @override
  void initState() {
    super.initState();
   /* _animationController = AnimationController(
      vsync: this,
      duration: Duration(seconds: 2),
    );
    _animationController.repeat(reverse: true);

    _timer = Timer.periodic(Duration(seconds: 2), (timer) {
      setState(() {
        _currentColor = _currentColor == Colors.pink ? Colors.red : Colors.pink;
      });
    });*/
  }

  @override
  void dispose() {
    // _animationController.dispose();
    // _timer.cancel();
    super.dispose();
  }
}

class RouterType {
  static String IN_USE = "IN_USE";
  static String READY_TO_USE = "READY_TO_USE";
  static String TO_BE_PICKED = "TO_BE_PICKED";
  static String TO_RETURN = "TO_RETURN";
}
